﻿namespace WebApplication1.Services.Linq
{
    public class Student
    {
        public Student(string name, int age, string course, double grade, string city)
        {
            Name = name;
            Age = age;
            Course = course;
            Grade = grade;
            City = city;
        }

        public string Name { get; set; }
        public int Age { get; set; }
        public string Course { get; set; }
        public double Grade { get; set; }
        public string City { get; set; }
    }

    public class LinqService : ILinqService
    {
        private List<Student> students = new List<Student>
        {
            new Student("T1", 25, "Math", 9.2, "New York"),
            new Student("T2", 29, "Physics", 8.5, "Los Angeles"),
            new Student("T3", 33, "Computer Science", 9.8, "Chicago"),
            new Student("T4", 22, "Math", 7.6, "Houston"),
            new Student("T5", 30, "Physics", 8.9, "San Francisco")
        };

        // Query 1: Where - Studenti dupa curs
        public List<Student> GetStudentsByCourse(string course)
        {
            return students.Where(s => s.Course == course).ToList();
        }

        // Query 2: Select specific property - Numele Studentilor
        public List<string> GetStudentNames()
        {
            return students.Select(s => s.Name).ToList();
        }

        // Query 3: Numara studentii cu o nota peste o valoare
        public int CountStudentsWithGradeAbove(double grade)
        {
            return students.Count(s => s.Grade > grade);
        }

        // Query 4: Where + Join - Studenti si orase
        public List<object> GetStudentsAndCities()
        {
            var cities = new List<(string Name, string State)>
            {
                ("New York", "NY"),
                ("Los Angeles", "CA"),
                ("Chicago", "IL"),
                ("Houston", "TX"),
                ("San Francisco", "CA")
            };

            var result = from s in students
                         join c in cities on s.City equals c.Name
                         select new { s.Name, s.Course, s.Grade, CityState = c.State };

            return result.ToList<object>();
        }
    }
}
