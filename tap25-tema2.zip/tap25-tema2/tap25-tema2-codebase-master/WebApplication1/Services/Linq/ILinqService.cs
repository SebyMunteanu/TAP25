﻿namespace WebApplication1.Services.Linq
{
    public interface ILinqService
    {
        List<Student> GetStudentsByCourse(string course);
        List<string> GetStudentNames();
        int CountStudentsWithGradeAbove(double grade);
        List<object> GetStudentsAndCities();
    }
}
