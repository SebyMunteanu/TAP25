﻿namespace WebApplication1.Services.Lambda
{
    public class LambdaService : ILambdaService
    {
        //tema
        // i. fara parametri
        public Func<string> NoParamLambda => () => "No parameters here!";
        // ii. Un parametru
        public Func<int, int> SquareNumber => (int x) => x * x;
        // iii. Doi parametri
        public Func<int, int, int> AddNumbers => (int x, int y) => x + y;
        // iv. Parametri neutilizati in expresie
        public Func<int, int> IgnoredParamLambda => (int x) => 42;  // Ignoră parametrul și returnează 42
        // v. Parametri cu valori default
        public Func<int, int, int> MultiplyNumbersWithDefaults => (int x, int y = 2) => x * y;
        // vi. Tuple ca parametru
        public Func<Tuple<int, int>, int> AddTupleNumbers => (Tuple<int, int> tuple) => tuple.Item1 + tuple.Item2;
        //
        public Tuple<int, int, int> SplitNumber(int value)
        {
            var lambdaExp = (int num) => new Tuple<int, int, int>(num % 10, (num /= 10) % 10, (num /= 10) % 10);
            return lambdaExp(value);
        }

        public bool TryParseNumber(string value)
        {
            return int.TryParse(value, out _);
        }

        public async Task<string> ToLowerCaseDelayed(string value)
        {
            var lambaExp = async (string v) =>
            {
                await Delay();
                return v.ToLower();
            };

            return await lambaExp(value);
        }


        public Task Delay()
        {
            return Task.Delay(10000);
        }
    }
}
