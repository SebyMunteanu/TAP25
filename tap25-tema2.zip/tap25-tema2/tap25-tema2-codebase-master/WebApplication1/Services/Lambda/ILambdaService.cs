﻿namespace WebApplication1.Services.Lambda
{
    public interface ILambdaService
    {
        Tuple<int, int, int> SplitNumber(int value);

        bool TryParseNumber(string value);

        Task<string> ToLowerCaseDelayed(string value);

        //tema
        Func<string> NoParamLambda { get; }
        Func<int, int> SquareNumber { get; }
        Func<int, int, int> AddNumbers { get; }
        Func<int, int> IgnoredParamLambda { get; }
        Func<int, int, int> MultiplyNumbersWithDefaults { get; }
        Func<Tuple<int, int>, int> AddTupleNumbers { get; }
    }
}
