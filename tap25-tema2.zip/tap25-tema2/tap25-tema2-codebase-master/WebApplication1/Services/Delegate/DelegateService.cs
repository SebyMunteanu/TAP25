﻿using System.Diagnostics;

namespace WebApplication1.Services.Delegate
{
    public class DelegateService : IDelegateService
    {
        public string Introduction(string value, Func<string, string, string> callback)
        {
            var upperName = value.ToUpper();
            return callback(upperName, "Test");
        }

        public string Hello(string firstname, string lastname)
        {
            return $"Hello, {firstname} {lastname}";
        }

        //tema
        public string ProcessMultiple(string value)
        {
            Action<string> multiAction = LogStart;
            multiAction += LogProcess;
            multiAction += LogEnd;

            multiAction(value);
            return "Process completed.";
        }
        private void LogStart(string value)
        {
            Console.WriteLine($"Starting process for {value}");
        }
        private void LogProcess(string value)
        {
            Console.WriteLine($"Processing {value}");
        }
        private void LogEnd(string value)
        {
            Console.WriteLine($"Finiched process for {value}");
        }
    }
}
