﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Services.Lambda;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TestLambdaController : ControllerBase
    {
        private readonly ILambdaService _lambdaService;

        public TestLambdaController(ILambdaService lambdaService)
        {
            _lambdaService = lambdaService;
        }

        [HttpGet("split-number")]
        public string SplitNumber(int value)
        {
            var tupleValue = _lambdaService.SplitNumber(value);
            return $"{tupleValue.Item1} / {tupleValue.Item2} / {tupleValue.Item3}";
        }

        [HttpGet("try-parse-number")]
        public string TryParseNumber(string value)
        {
            return _lambdaService.TryParseNumber(value) ? "Number" : "Not number";
        }

        [HttpGet("lower-case-delayed")]
        public string ToLowerCaseDelayed(string value)
        {
            var result = _lambdaService.ToLowerCaseDelayed(value).Result;
            return result;
        }
        
        //tema
        // Expozăm Lambda fără parametri
        [HttpGet("no-param-lambda")]
        public string NoParamLambda()
        {
            return _lambdaService.NoParamLambda();  // Apelezi metoda pentru a obține rezultatul
        }


        // Expozăm Lambda cu un parametru
        [HttpGet("square-number")]
        public int SquareNumber(int value)
        {
            return _lambdaService.SquareNumber(value);
        }

        // Expozăm Lambda cu doi parametri
        [HttpGet("add-numbers")]
        public int AddNumbers(int x, int y)
        {
            return _lambdaService.AddNumbers(x, y);
        }

        // Expozăm Lambda cu parametri neutilizați
        [HttpGet("ignored-param-lambda")]
        public int IgnoredParamLambda(int x)
        {
            return _lambdaService.IgnoredParamLambda(x);  // Apelăm delegatul și obținem rezultatul
        }


        // Expozăm Lambda cu parametri cu valori default
        [HttpGet("multiply-numbers-with-defaults")]
        public int MultiplyNumbersWithDefaults(int x, int y = 2)
        {
            return _lambdaService.MultiplyNumbersWithDefaults(x, y);
        }

        // Expozăm Lambda cu Tuple ca parametru
        [HttpGet("add-tuple-numbers")]
        public int AddTupleNumbers(int x, int y)
        {
            var tuple = new Tuple<int, int>(x, y);
            return _lambdaService.AddTupleNumbers(tuple);
        }
    }
}
