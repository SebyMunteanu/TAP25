﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Services.Linq;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TestLinqController : ControllerBase
    {
        private readonly ILinqService _linqService;

        public TestLinqController(ILinqService linqService)
        {
            _linqService = linqService;
        }

        [HttpGet("students-by-course")]
        public IActionResult GetStudentsByCourse(string course)
        {
            return Ok(_linqService.GetStudentsByCourse(course));
        }

        [HttpGet("student-names")]
        public IActionResult GetStudentNames()
        {
            return Ok(_linqService.GetStudentNames());
        }

        [HttpGet("count-students-grade-above")]
        public IActionResult CountStudentsWithGradeAbove(double grade)
        {
            return Ok(_linqService.CountStudentsWithGradeAbove(grade));
        }

        [HttpGet("students-cities")]
        public IActionResult GetStudentsAndCities()
        {
            return Ok(_linqService.GetStudentsAndCities());
        }
    }
}
