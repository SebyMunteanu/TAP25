﻿using DataAccessLayer.Models;
using DataAccessLayer.Repository;
using Microsoft.AspNetCore.Mvc;
using WebAPI.Dto;

namespace WebAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CourseController : ControllerBase
    {
        private readonly IRepository<Course> _repository;

        public CourseController(IRepository<Course> repository)
        {
            _repository = repository;
        }

        [HttpGet("get")]
        public IEnumerable<Course> Get()
        {
            return _repository.GetAll();
        }

        [HttpPost("add")]
        public IActionResult Add(CourseDto dto)
        {
            var course = new Course
            {
                Title = dto.Title
            };

            _repository.Add(course);
            _repository.SaveChanges();
            return Ok("Added successfully.");
        }

        [HttpPut("update")]
        public IActionResult Update(Guid id, CourseDto dto)
        {
            var course = _repository.GetById(id);
            if (course == null) return NotFound("Course not found.");

            course.Title = dto.Title;

            _repository.Update(course);
            _repository.SaveChanges();
            return Ok("Updated successfully.");
        }

        [HttpDelete("delete")]
        public IActionResult Delete(Guid id)
        {
            var course = _repository.GetById(id);
            if (course == null) return NotFound("Course not found.");

            _repository.Delete(course);
            _repository.SaveChanges();
            return Ok("Deleted successfully.");
        }
    }
}
