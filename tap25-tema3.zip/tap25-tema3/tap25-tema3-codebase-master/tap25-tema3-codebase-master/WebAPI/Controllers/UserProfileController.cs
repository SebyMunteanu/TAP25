﻿using DataAccessLayer.Models;
using DataAccessLayer.Repository;
using Microsoft.AspNetCore.Mvc;
using WebAPI.Dto;

namespace WebAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class UserProfileController : ControllerBase
    {
        private readonly IRepository<UserProfile> _repository;

        public UserProfileController(IRepository<UserProfile> repository)
        {
            _repository = repository;
        }

        [HttpGet("get")]
        public IEnumerable<UserProfile> Get()
        {
            return _repository.GetAll();
        }

        [HttpPost("add")]
        public IActionResult Add(UserProfileDto dto)
        {
            var profile = new UserProfile
            {
                Bio = dto.Bio,
                UserId = dto.UserId
            };

            _repository.Add(profile);
            _repository.SaveChanges();
            return Ok("Added successfully.");
        }

        [HttpPut("update")]
        public IActionResult Update(Guid id, UserProfileDto dto)
        {
            var profile = _repository.GetById(id);
            if (profile == null) return NotFound("Profile not found.");

            profile.Bio = dto.Bio;
            profile.UserId = dto.UserId;

            _repository.Update(profile);
            _repository.SaveChanges();
            return Ok("Updated successfully.");
        }

        [HttpDelete("delete")]
        public IActionResult Delete(Guid id)
        {
            var profile = _repository.GetById(id);
            if (profile == null) return NotFound("Profile not found.");

            _repository.Delete(profile);
            _repository.SaveChanges();
            return Ok("Deleted successfully.");
        }
    }
}
