﻿using DataAccessLayer.Models;
using DataAccessLayer.Repository;
using Microsoft.AspNetCore.Mvc;
using WebAPI.Dto;

namespace WebAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class StudentController : ControllerBase
    {
        private readonly IRepository<Student> _repository;

        public StudentController(IRepository<Student> repository)
        {
            _repository = repository;
        }

        [HttpGet("get")]
        public IEnumerable<Student> Get()
        {
            return _repository.GetAll();
        }

        [HttpPost("add")]
        public IActionResult Add(StudentDto dto)
        {
            var student = new Student
            {
                FullName = dto.FullName
            };

            _repository.Add(student);
            _repository.SaveChanges();
            return Ok("Added successfully.");
        }

        [HttpPut("update")]
        public IActionResult Update(Guid id, StudentDto dto)
        {
            var student = _repository.GetById(id);
            if (student == null) return NotFound("Student not found.");

            student.FullName = dto.FullName;

            _repository.Update(student);
            _repository.SaveChanges();
            return Ok("Updated successfully.");
        }

        [HttpDelete("delete")]
        public IActionResult Delete(Guid id)
        {
            var student = _repository.GetById(id);
            if (student == null) return NotFound("Student not found.");

            _repository.Delete(student);
            _repository.SaveChanges();
            return Ok("Deleted successfully.");
        }
    }
}
