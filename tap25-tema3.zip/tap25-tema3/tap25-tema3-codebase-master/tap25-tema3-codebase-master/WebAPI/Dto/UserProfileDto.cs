﻿namespace WebAPI.Dto
{
    public class UserProfileDto
    {
        public string Bio { get; set; }
        public Guid UserId { get; set; }
    }
}
