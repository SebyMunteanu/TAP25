﻿namespace WebAPI.Dto
{
    public class StudentDto
    {
        public string FullName { get; set; }
    }
}
