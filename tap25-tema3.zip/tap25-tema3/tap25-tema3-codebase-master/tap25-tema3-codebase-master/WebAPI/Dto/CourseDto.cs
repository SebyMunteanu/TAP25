﻿namespace WebAPI.Dto
{
    public class CourseDto
    {
        public string Title { get; set; }
    }
}
