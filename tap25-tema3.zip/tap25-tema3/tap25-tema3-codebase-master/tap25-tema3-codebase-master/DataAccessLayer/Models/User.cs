﻿namespace DataAccessLayer.Models
{
    public class User
    {
        public User() { }
        public User(string name, string email, string password, Guid typeId)
        {
            Name = name;
            Email = email;
            Password = password;
            TypeId = typeId;
        }

        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }

        // relatie one-to-many
        public Guid TypeId { get; set; }
        public UserType Type { get; set; }

        // relatie one-to-one
        public UserProfile Profile { get; set; }
    }
}
