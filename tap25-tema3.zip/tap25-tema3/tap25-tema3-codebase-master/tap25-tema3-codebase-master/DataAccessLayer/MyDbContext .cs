﻿using DataAccessLayer.Models;
using Microsoft.EntityFrameworkCore;

namespace DataAccessLayer
{
    //Install: Microsoft.EntityFrameworkCore.SqlServer, Microsoft.EntityFrameworkCore.Design
    // dotnet ef migrations add Initial
    // dotnet ef database update
    public class MyDbContext : DbContext
    {
        //ex 1.a
        private readonly string _windowsConnectionString = @"Server=.\SQLExpress;Database=Lab5Database1;Trusted_Connection=True;TrustServerCertificate=true";
        //private readonly string _windowsConnectionString = @"Server=localhost\SQLEXPRESS;Database=Lab5Database1;Trusted_Connection=True;TrustServerCertificate=True;";

        public DbSet<User> Users { get; set; }
        public DbSet<UserType> UserTypes { get; set; }

        //ex 2.a.iii
        public DbSet<UserProfile> UserProfiles { get; set; }
        public DbSet<Student> Students { get; set; }
        public DbSet<Course> Courses { get; set; }
        public DbSet<StudentCourse> StudentCourses { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(_windowsConnectionString);
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            //ex 2.a.ii - one-to-many
            builder.Entity<User>()
                .HasOne(f => f.Type)
                .WithMany(c => c.Users)
                .HasForeignKey(f => f.TypeId);

            //ex 2.a.i - one-to-one
            builder.Entity<User>()
                .HasOne(u => u.Profile)
                .WithOne(p => p.User)
                .HasForeignKey<UserProfile>(p => p.UserId);

            //ex 2.a.iii - many-to-many
            builder.Entity<StudentCourse>()
                .HasKey(sc => new { sc.StudentId, sc.CourseId });

            builder.Entity<StudentCourse>()
                .HasOne(sc => sc.Student)
                .WithMany(s => s.StudentCourses)
                .HasForeignKey(sc => sc.StudentId);

            builder.Entity<StudentCourse>()
                .HasOne(sc => sc.Course)
                .WithMany(c => c.StudentCourses)
                .HasForeignKey(sc => sc.CourseId);

            var adminTypeId = new Guid("11111111-1111-1111-1111-111111111111");
            var clientTypeId = new Guid("22222222-2222-2222-2222-222222222222");

            builder.Entity<UserType>().HasData(
                new UserType { Id = adminTypeId, Name = "Admin" },
                new UserType { Id = clientTypeId, Name = "Client" }
            );
            builder.Entity<User>().HasData(
                new User
                {
                Id = new Guid("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"),
                Name = "admin",
                Email = "admin@example.com",
                Password = "admin",
                TypeId = adminTypeId
                }
            );

            var courseId1 = new Guid("44444444-4444-4444-4444-444444444444");
            var courseId2 = new Guid("55555555-5555-5555-5555-555555555555");


            builder.Entity<Course>().HasData(
                new Course { Id = courseId1, Title = "Mathematics" },
                new Course { Id = courseId2, Title = "Physics" }
            );

            var studentId1 = new Guid("66666666-6666-6666-6666-666666666666");
            var studentId2 = new Guid("77777777-7777-7777-7777-777777777777");

            builder.Entity<Student>().HasData(
                new Student { Id = studentId1, FullName = "Alice Popescu" },
                new Student { Id = studentId2, FullName = "Bogdan Ionescu" }
            );
            builder.Entity<StudentCourse>().HasData(
                new StudentCourse { StudentId = studentId1, CourseId = courseId1 },
                new StudentCourse { StudentId = studentId1, CourseId = courseId2 },
                new StudentCourse { StudentId = studentId2, CourseId = courseId1 }
            );
            var userId = new Guid("33333333-3333-3333-3333-333333333333");

            builder.Entity<UserProfile>().HasData(
                new UserProfile
                {
                    Id = 1,
                    Bio = "Admin profile",
                    UserId = userId
                }
            );
        }
    }
}
