﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleProject.Interfaces
{
    public interface IMemberManager
    {
        void AddMember(string member);
        bool MemberExists(string member);
    }
}
