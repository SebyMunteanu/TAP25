﻿using ConsoleProject.Interfaces;
using ConsoleProject.Managers;
using ConsoleProject.Services;

namespace ConsoleProject
{
    /*
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Starting Client...");

            // This code demonstrates a library system that violates SOLID principles.
            LibrarySystem library = new LibrarySystem();
            library.AddBook("The Great Gatsby");
            library.AddMember("John Doe");
            library.BorrowBook("John Doe", "The Great Gatsby");
            library.ReturnBook("John Doe", "The Great Gatsby");

            // Hints:
            // 1. SRP: Separate the responsibilities of managing books and members into different classes.
            // 2. OCP: Use inheritance or interfaces to allow adding new book types without modifying existing code.
            // 3. LSP: Ensure that derived classes can be substituted for their base classes without altering the correctness of the program.
            // 4. ISP: Split the LibrarySystem interface into smaller, more specific interfaces.
            // 5. DIP: Depend on abstractions (e.g., interfaces) rather than concrete classes.
        }
    }
    */
    class Program
    {
        static void Main(string[] args)
        {
            // Initializam serviciile
            IBookManager bookManager = new BookManager();
            IMemberManager memberManager = new MemberManager();
            IBorrowManager borrowManager = new BorrowManager(bookManager, memberManager);
            ILibrarySystem library = new LibrarySystem(bookManager, memberManager, borrowManager);

            // Meniu interactiv
            while (true)
            {
                Console.WriteLine("\n=== Sistemul de Biblioteca ===");
                Console.WriteLine("1. Adauga carte");
                Console.WriteLine("2. Adauga membru");
                Console.WriteLine("3. Imprumuta carte");
                Console.WriteLine("4. Returneaza carte");
                Console.WriteLine("5. Afiseaza toate cartile");
                Console.WriteLine("6. Iesi");
                Console.Write("Alege o optiune: ");

                string input = Console.ReadLine();
                switch (input)
                {
                    case "1": // Adauga carte
                        Console.Write("Introdu numele cartii: ");
                        string book = Console.ReadLine();
                        library.AddBook(book);
                        break;

                    case "2": // Adauga membru
                        Console.Write("Introdu numele membrului: ");
                        string member = Console.ReadLine();
                        library.AddMember(member);
                        break;

                    case "3": // Imprumuta carte
                        Console.Write("Introdu numele membrului: ");
                        string borrowMember = Console.ReadLine();
                        Console.Write("Introdu numele cartii: ");
                        string borrowBook = Console.ReadLine();
                        library.BorrowBook(borrowMember, borrowBook);
                        break;

                    case "4": // Returneaza carte
                        Console.Write("Introdu numele membrului: ");
                        string returnMember = Console.ReadLine();
                        Console.Write("Introdu numele cartii: ");
                        string returnBook = Console.ReadLine();
                        library.ReturnBook(returnMember, returnBook);
                        break;

                    case "5": // Afiseaza toate cartile
                        var allBooks = bookManager.GetAllBooks();
                        Console.WriteLine("Carti disponibile:");
                        foreach (var b in allBooks)
                        {
                            Console.WriteLine(b);
                        }
                        break;

                    case "6": // Iesi
                        Console.WriteLine("Iesire din sistem...");
                        return;

                    default:
                        Console.WriteLine("Optiune invalida. Incearca din nou.");
                        break;
                }
            }
        }
    }
}
                
