﻿using ConsoleProject.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleProject.Managers
{
    public class BorrowManager : IBorrowManager
    {
        private Dictionary<string, string> borrowedBooks = new Dictionary<string, string>();
        private readonly IBookManager _bookManager;
        private readonly IMemberManager _memberManager;
        public BorrowManager(IBookManager bookManager, IMemberManager memberManager)
        {
            _bookManager = bookManager;
            _memberManager = memberManager;
        }
        public void BorrowBook(string member, string book)
        {
            if (_memberManager.MemberExists(member) && _bookManager.BookExists(book))
            {
                borrowedBooks[book] = member;
                Console.WriteLine($"Book '{book}' borrowed by '{member}'.");
            }
            else
            {
                Console.WriteLine("Member or book not found.");
            }
        }
        public void ReturnBook(string member, string book)
        {
            if (borrowedBooks.ContainsKey(book) && borrowedBooks[book] == member)
            {
                borrowedBooks.Remove(book);
                Console.WriteLine($"Book '{book}' returned by '{member}'.");
            }
            else
            {
                Console.WriteLine("Book not borrowed by this member.");
            }
        }
    }
}
