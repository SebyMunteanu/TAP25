﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using ConsoleProject.Interfaces;

namespace ConsoleProject.Managers
{
    public class MemberManager : IMemberManager
    {
        private List<string> members = new List<string>();
        public void AddMember(string member)
        {
            members.Add(member);
            Console.WriteLine($"Member '{member}' added successfully to the Library");
        }
        public bool MemberExists(string member)
        {
            return members.Contains(member);
        }
    }
}
