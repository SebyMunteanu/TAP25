﻿using ConsoleProject.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Reflection.Metadata.BlobBuilder;

namespace ConsoleProject.Managers
{
    public class BookManager : IBookManager
    {
        private List<string> books = new List<string>();
        public void AddBook(string book)
        {
            books.Add(book);
            Console.WriteLine($"Book '{book}'added successfully to the Library");
        }
        public bool BookExists(string book)
        {
            return books.Contains(book);
        }
        public List<string> GetAllBooks()
        {
            return books;
        }
    }
}
