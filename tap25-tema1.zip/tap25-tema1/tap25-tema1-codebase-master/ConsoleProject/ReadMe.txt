READ ME : Cuprins
- rezumatul proiectului
- subiect 1
- subiect 2


Read Me - rezumatul proiectului
1. Cum este respectat SOLID : 
                             Pas 1 : Am creat clase separate pentru fiecare sarcina:
                             -> BookManager - pentru carti
                             -> MemberManager - pentru membri
                             -> BorrowManager - pentru imprumuturi
                             
                             Pas 2 : Am folosit interfete (ISP si DIP): 
                             -> am creat interfetele (IBookManager, IMemberManager, IBorrowManager) pentru a descrie ce poate face fiecare clasa
                             -> clasele depind de interfete, nu de implementari concrete - poti schimba cum functioneaza o clasa fara sa afectezi restul programului

                             Pas 3 : Am facut codul deschis pentru extindere (OCP):
                             -> daca vrei sa adaugi o noua functionalitate (Exemplu : sa gestionezi reviste), poti crea o clasa noua fara sa modifici codul existent

                             Pas 4 : Am respectat LSP:
                             -> toate clasele care implementeaza interfetele pot fi inlocuite fara probleme.
                             Exemplu : daca ai o alta implementare pentru IBookManager, poti sa o folosesti fara sa strici programul

2. Program interactiv
Pas 1 : am creat un meniu
Pas 2 : am facut programul sa asculte de comenzile utilizatorului
Pas 3 : am facut programul sa se repete 
--- Detalii : vezi ReadMe - dezvoltarea rezumatului proiectului ---

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
SUBIECTUL 1 :

Read Me - dezvoltarea rezumatuului proiectului
Recapitulare:
- Principiile SOLID

                   1. S - Single Responsibility Principle (SPR): 
                   ! fiecare clasa trebuie sa aiba o singura sarcina
                   -> o clasa care gestioneaza cartile       - BookManager (adauga carti si verifica daca o carte exista)
                   -> o clasa care gestioneaza membrii       - MemberManager (adauga membri si verifica daca un membru exista)
                   -> o clasa care gestioneaza imprumuturile - BorrowManager (imprumuta si returneaza carti)
                   ! Importanta: 
                   -> daca vrei sa schimbi cum functioneaza carile, nu trebuie sa te uiti la codul membri sau imprumuturi
                   -> este mai usor de inteles si de reparat

                   2. O - Open/Closed Principle (OCP):
                   ! codul trebuie sa fie deschis pentru extindere (poti adauga lucruri noi), dar inchis pentru modificare (nu trebuie sa schimbi codul vechi).
                   Aplicare:
                            -> am folosit interfete (de exemplu, IBookManager, IMemberManager, IBorrowManager).
                            -> daca vrei sa adaugi o noua functionalitate (de exemplu, sa gestionezi reviste), poti crea o clasa noua care sa implementeze o interfata, fara sa modifici codul existent.
                   Exemplu: 
                           -> daca vrei sa adaugi reviste, creezi o clasa MagazineManager care implementeaza o interfata IMagazineManager. Nu trebuie sa schimbi BookManager, MemberManager sau BorrowManager.
                   ! Importanta:
                                -> poti adauga functionalitati noi fara sa risti sa strici ce functioneaza deja    

                   3. L - Liskov Substitution Principle (LSP):
                   ! daca ai o clasa de baza (Exemplu : o clasa care gestioneaza carti), orice clasa care o inlocuieste trebuie sa functioneze la fel
                   Aplicare: 
                            -> toate clasele care implementeaza o interfata (de exemplu, BookManager care implementeaza IBookManager) pot fi inlocuite cu alte implementari fara probleme.
                            -> de exemplu, daca ai o alta implementare a IBookManager (de exemplu, AdvancedBookManager), poti sa o folosesti fara sa modifici restul programului.
                   !Importanta:
                                -> poti schimba cum functioneaza o parte a programului fara sa afectezi celelalte parti.

                   4. I - Interface Segregation Principle (ISP):
                   -> clasele nu trebuie sa fie fortate sa faca lucruri pe care nu le folosesc
                   Exemplu : daca o clasa gestioneaza doar carti, nu trebuie sa faca si lucruri legate de membri 
                   Aplicare :
                            -> am creat interfete mici si specifice:
                                                                   -> IBookManager are metode doar pentru carti.
                                                                   -> IMemberManager are metode doar pentru membri.
                                                                   -> IBorrowManager are metode doar pentru imprumuturi.
                   !Importanta:
                               -> clasele nu sunt foraate sa implementeze metode inutile. De exemplu, BookManager nu trebuie sa stie nimic despre membri sau imprumuturi.


                   5. D - Dependency Inversion Principle (DIP):
                   -> clasele trebuie sa depinda de abstractii (interfete),  nu de implementari concrete - poti schimba cum functioneaza o clasa fara sa afectezi restul programului
                   Alicare: 
                          -> clasa LibrarySystem depinde de interfete (IBookManager, IMemberManager, IBorrowManager), nu de clase concrete (BookManager, MemberManager, BorrowManager).
                          -> Dependentele sunt injectate prin constructor.
                          Exemplu: 
                                  public LibrarySystem(IBookManager bookManager, IMemberManager memberManager, IBorrowManager borrowManager)
                                  {
                                      _bookManager = bookManager;
                                      _memberManager = memberManager;
                                      _borrowManager = borrowManager;
                                  }
                   !Importanta:
                               -> poti schimba implementarile (de exemplu, folosesti AdvancedBookManager in loc de BookManager) fara sa modifici LibrarySystem.



- Programul interactiv 
                      1. Meniu 
                      -> am adaugat un meniu in program care afiseaza optiuni si te lasa sa alegi ce vrei sa faci.
                      -> meniul arata astfel : 
                                              === Sistemul de Biblioteca ===
                                              1. Adauga carte
                                              2. Adauga membru 
                                              3. Imprumuta carte
                                              4. Returneaza carte
                                              5. Afiseaza toate cartile
                                              6. Iesi
                                              Alege o optiune:

                      2. Ascultarea comenzilor utilizatorului
                      -> am scris un cod care citeste ce ai tastat si face ce ai cerut
                      Exemplu: 
                              -> daca tastezi 1, programul te intreaba "Introdu numele cartii: " si apoi adauga in biblioteca
                              -> daca tastezi 3, programul te intreaba "Introdu numele membrului: " si "Introdu numele cartii: " si apoi imprumuta cartea

                      3. Repetarea programului
                      -> dupa fiecare actiune, programul afiseaza meniul din nou, ca sa poti face mai multe lucruri fara sa-l opresti
                      -> daca tastezi 6, programul se opreste

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

SUBIECTUL 2 :
1. Principiul aplicat (daca este cazul)
2. Descrierea implementarii efectuate
3. De ce s-a ales implementarea respectiva
4. Cum incalca (sau respecta) implementarea curenta definitia principiului
5. Daca modificarea nu are legatura cu un principiu SOLID, ci doar imbunatateste codul

1. Separea cu modificari aduse :
  1. Separarea responsabilitatilor in clase diferite
    a. Principiul aplicat  
      -> Single Responsibility Principle (SPR)
    b. Descrierea implementarii efectuate
      -> am creat clase separate pentru fiecare responsabilitate:
         BookManager - pentru gestionarea cartilor
         MemberManager - pentru gestionarea membrilor
         BorrowManager - pentru gestionarea imprumuturilor
    c. De ce s-a ales implementarea respectiva:
      -> pentru a face codul mai usor de inteles si de intretinut. Fiecare clasa are o singura sarcina, ceea ce reduce complexitatea
    d. Cum respecta SRP:
      -> fiecare clasa are o singura responsabilitate:
        BookManager - se ocupa doar de carti
        MemberManager - se ocupa doar de membri
        BorrowManager - se ocupa doar de imprumuturi

  2. Folosirea interfetelor pentru dependente
    a. Principiul aplicat:
      -> Dependency Inversion Principle (DIP)
      -> Interface Segregation Principle (ISP)
    b. Descrierea implementarii efectuate:
      -> am creat interfetele : IBookManager, IMemberManager, IBorrowManager
        -> si am facut clasele sa depinda de aceste interfete, nu de implementari concrete
    c. De ce s-a ales implementarea respectiva:
      -> pentru a face codul mai flexibil si usor de testat. Daca vrei sa schimbi o implementare (Exemplu: sa folosesti AdvanceBookManager in loc de BookManager), nu trebuie sa modifici clasele care folosesc interfata
    d. Cum respecta DIP si ISP:
      -> clasele depind de abstractii (interfete), nu de implemntari concrete
      -> interfetele sunt mici si specifice, astfel incat clasele nu sunt fortate sa implementeze metode inutile

  3. Adaugarea unui meniu interactiv
    a. Principiul aplicat:
      -> N/A (nu are legatura directa cu SOLID, ci este o imbunatatire a codului)
    b. Descrierea implementarii efectuate:
      -> am adaugat un meniu interactiv in Program.cs care permite utilizatorului sa aleaga optiuni direct din terminal
    c. De ce s-a ales implementarea respectiva:
      -> pentru a fac eprogramul mai usor de folosit si mai interactiv. Utilizatorul nu mai trebuie sa modifice codul pentru a efectua actiuni
    d. Cum incalca sau respecta SOLID:
      -> nu incalca niciun principiu SOLID. Este o imbunatatire a experientei utilizatorului

  4. Adaugarea functionalitatii de afisare a tuturor cartilor
    a. Principiul aplicat:
      -> Open/Closed Principle (OCP)
    b. Descrierea implementarii efectuate:
      -> am adaugat o metoda noua in IBookManager si BookManager pentru a afisa toate cartile din biblioteca.
    c. De ce s-a ales implementarea respectiva:
      -> pentru a permite utilizatorului sa vada toate cartile disponibile fara a modifica codul.
    d. Cum respecta OCP:
      -> am extins functionalitatea sistemului fara a modifica codul existent. Am adaugat o metoda noua (GetAllBooks) fara a schimba comportamentul claselor existente.

  5. Folosirea Dependency Injection in LibrarySystem
    a. Principiul aplicat
      -> Dependency Iversion Principle (DIP)
    b. Descrierea implementarii efectuate
      -> am modificat constructorul clasei LibrarySystem pentru a primi dependentele (IBookManager, IMemberManager, IBorrowManager) ca parametri.
    c. De ce s-a ales implementarea respectiva
      -> pentru a face clasa LibrarySystem mai flexibila si usor de testat. Poti sa folosesti orice implementare a interfetelor fara sa modifici LibrarySystem.
    d. Cum respecta DIP:
      -> LibrarySystem depinde de abstractii (interfete), nu de implementari concrete.

  6. Adaugarea validarilor in BorrowManager
    a. Principiul aplicat
      -> N/A (nu are legatura directa cu SOLID, ci este o imbunatatire a codului)
    b. Descrierea implentarii efectuate
      -> am adaugat validari in BorrowManager pentru a verifica daca o carte sau un membru exista inainte de a permite un imprumut.
    c. De ce s-a ales implementarea respectiva:
      -> pentru a preveni erori (de exemplu, imprumutarea unei carti care nu exista).
    d. Cum incalca sau respecta SOLID
      -> nu incalca niciun principiu SOLID. Este doar o imbunatatire a logicii de business.
